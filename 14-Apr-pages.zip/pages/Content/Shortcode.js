import React from 'react';

function Shortcode() {
  return (
    <>  
       <div>
           <p> Short Code will show In this component</p>
       </div>
       
    </>
  )
}

export default Shortcode;