import { configureStore } from '@reduxjs/toolkit'

import styleReducer from './styleslice.js';

export default configureStore({
  reducer: {
    style: styleReducer
  }
})