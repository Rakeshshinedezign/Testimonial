// import React, { useCallback } from 'react';
// import { useSelector } from 'react-redux';

// function Output()  {
//     return(
//         <>
         
//           <p>Desktop Icon</p><p>Mobile icon</p>
//         </>
//     );
// }
// export default Output;

import React from 'react';
import { useSelector } from 'react-redux';




const PostsList = () => {
  const style = useSelector(state => state.style.slice(-1))
  //const style = useSelector(state => state.style)
  //const style = useSelector(state => state.style[style.length - 1])

  console.log(style);
  

  const renderedPosts = style.map(style => ( 
    <article className="post-excerpt" >
      <h3>{style.value}</h3>  
    </article>
  ))
  console.log(renderedPosts);
  if(renderedPosts == 'multiple'){
    return(
      <div>
        Hello  its multiple
      </div>
    )
  }else{
  return (
    <section className="posts-list">
      <h2>Posts</h2>
      {/* {style} */}
       {renderedPosts}
    </section>
  )
}
}
export default PostsList;
