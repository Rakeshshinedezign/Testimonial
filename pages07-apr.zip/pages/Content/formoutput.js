import React from 'react'
import { useSelector } from 'react-redux'
import {Heading} from '@shopify/polaris';

 const Formoutput = () => {
  const form = useSelector(state => state.form)

  const renderedform = form.map(post => (
      <>
    {/* <article className="post-excerpt" key={post.id}>
      <h3>{post.heading}</h3>
      <p className="post-content">{post.description.substring(0, 100)}</p>
      {post.name}
    </article> */}
    <div className="main">
          <div className="star-rating">
            <h1>*****</h1>
          </div>
        <div className="title">
         
          <Heading>{post.heading}</Heading>
        </div>
        <div className="content">
          <p>{post.description}</p>
        </div>
        <div>
          <div className="image">
          <img src="https://cdn.shopify.com/s/files/1/0540/6955/9467/t/1/assets/multiple.png?v=1617777079"  height="50px" width="50px"/>
          </div>
          <div className="name-date">
          {post.name} <br />
            Date
          </div>
        </div>
      </div>
    </>
  ))

  return (
    <section className="form-list">
      
      {renderedform}
    </section>
  )
}

export default Formoutput;