
import React, {useCallback, useState} from 'react';
import {Button, TextField, Form, FormLayout , Page , DatePicker} from '@shopify/polaris';
import {Stack, RadioButton} from '@shopify/polaris';

import { useDispatch } from 'react-redux';
import { nanoid } from '@reduxjs/toolkit';

import { formAdd } from './Content/redux/formSlice';
import { FaStar } from "react-icons/fa";

 function Testimonialcontentform() {
  const [selectedStars, setSelectedStars] = useState(0);
  const [heading, setHeading] = useState(''); 

  const [description, setDescription] = useState(''); 
  const [starRating, setstarRating] = useState('');
  const [name, setName] = useState(''); 
  
  

  
  
 
  //const headingChange = useCallback((value) => setHeading(value), []);
  const onheadingChanged = useCallback((value) => setHeading(value), []);  
  const descriptionChange = useCallback((value) => setDescription(value), []);
  const NameChange = useCallback((value) => setName(value), []);
  const dispatch = useDispatch()

  const adddata = () => {    
    console.log('form submit')
    if (heading && description && name) {
      dispatch(
        formAdd({
          id: nanoid(),
          heading,
          description ,
          name
        })
      )
      setHeading('')
      setDescription('')
      setName('')
    }
  }


 
  return (
    <>
    {/* <Header /> */}
   
      {/* <Button primary>Back</Button> */}
       
    <Page>
    
      <Form >
        <FormLayout>
        
          <TextField type="text" value={heading} onChange={onheadingChanged} label=" Heading"  />

          <TextField value={description} onChange={descriptionChange} label="  Description "  multiline={4}/>

          <TextField value={name} onChange={NameChange} label=" Name"  />

          
          <Button onClick={adddata}>Submit</Button>
        </FormLayout>
      </Form>
      </Page>
    </>
  );
}





export default Testimonialcontentform;
