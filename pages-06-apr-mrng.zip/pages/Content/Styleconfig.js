import React, {useCallback, useState} from 'react';
import {ChoiceList} from '@shopify/polaris';
import Sibling1 from './Sibling1.js';
//import { createSlice } from '@reduxjs/toolkit';


function Styleconfig() {
  const [selected, setSelected] = useState([]);
  const handleChange = useCallback((value) => setSelected(value), []);
  console.log(selected);

  return (
    <>  
       {/* <div>
           <p> Styleconfigration Code will show In this component</p> 
       </div> */}
       <ChoiceList   title="Select Template"
      choices={[
        {label :<Sibling1 />  , value: 'multiple'},
        {label: 'Single Crouser', value: 'single'},
        {label: 'Grid', value: 'grid'},
        {label: 'List Style', value: 'list'},
        {label: 'Row Wise show', value: 'row'},
      ]}
      selected={selected}
      onChange={handleChange}
    />
       
    </>
  )
}

export default Styleconfig;