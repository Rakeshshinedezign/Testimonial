import React, {useCallback, useState} from 'react';
import { Heading, Page } from "@shopify/polaris";
import {Button} from '@shopify/polaris';
import Dashboard from "./Dashboard.js";
//import Header from './Header.js'
import TableData from './Tabledata.js';
import AddTripButton from './test.js';
import { TextField, Form, FormLayout , DatePicker} from '@shopify/polaris';
import {Stack, RadioButton} from '@shopify/polaris';
import Header from './Header.js';
import Parent from './test.js';


function Index() {
   return (
    <div>
          <Dashboard />
          {/* <Parent />  */}
    </div>

  )
}

export default Index;
