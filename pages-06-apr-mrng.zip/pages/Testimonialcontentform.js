
import React, {useCallback, useState} from 'react';
import {Button, TextField, Form, FormLayout , Page , DatePicker} from '@shopify/polaris';
import {Stack, RadioButton} from '@shopify/polaris';
import Header from './Header.js';
import Output from './Content/Output.js';
import Link from 'next/link';
import Content from './Content/Content'


 function Testimonialcontentform() {
  const [heading, setHeading] = useState(''); 
  const [description, setDescription] = useState(''); 
  const [starRating, setstarRating] = useState('');
  const [name, setName] = useState(''); 
  const [dataGet,setdataGet] = useState([]);
 
  const [{month, year}, setDate] = useState({month: 1, year: 2018});
  const [selectedDates, setSelectedDates] = useState({
    start: new Date('Wed Feb 07 2018 00:00:00 GMT-0500 (EST)'),
    end: new Date('Wed Feb 07 2018 00:00:00 GMT-0500 (EST)'),
  });

  const handleMonthChange = useCallback(
    (month, year) => setDate({month, year}),
    [],
  );
  const starRatingChange = useCallback((_checked, newValue) => setstarRating(newValue),[],);
  
  const headingChange = useCallback((value) => setHeading(value), []);
  const descriptionChange = useCallback((value) => setDescription(value), []);
  const NameChange = useCallback((value) => setName(value), []);
  



  
  return (
    <>
    {/* <Header /> */}
   
      {/* <Button primary>Back</Button> */}
       
    <Page>
    
      <Form >
        <FormLayout>
          {starRating} {heading}  {description} {name}
          <p>Star Rating</p>  
          <RadioButton label="1" checked={starRating === '1'} id="1" name="star_rating" onChange={starRatingChange} />
          <RadioButton label="2" checked={starRating === '2'} id="2" name="star_rating" onChange={starRatingChange} />
          <RadioButton label="3" checked={starRating === '3'} id="3" name="star_rating" onChange={starRatingChange} />
          <RadioButton label="4" checked={starRating === '4'} id="4" name="star_rating" onChange={starRatingChange} />
          <RadioButton label="5" checked={starRating === '5'} id="5" name="star_rating" onChange={starRatingChange} /> 

          <TextField value={heading} onChange={headingChange} label=" Heading"  />

          <TextField value={description} onChange={descriptionChange} label="  Description "  multiline={4}/>

          <TextField value={name} onChange={NameChange} label=" Name"  />

          <DatePicker
            month={month}
            year={year}
            onChange={setSelectedDates}
            onMonthChange={handleMonthChange}
            selected={selectedDates}
            disableDatesBefore={new Date('Sat Feb 03 2018 00:00:00 GMT-0500 (EST)')}
            disableDatesAfter={new Date('Sun Feb 18 2018 00:00:00 GMT-0500 (EST)')}
            allowRange
          />
        
      
          <Button submit>Submit</Button>
        </FormLayout>
      </Form>
      </Page>
    </>
  );
}





export default Testimonialcontentform;
