import { configureStore } from '@reduxjs/toolkit'

import styleReducer from './styleslice.js';
import formReducer from './formSlice.js';
import cssReducer from './cssSlice.js';



export default configureStore({
  reducer: {
    style: styleReducer,
    form:formReducer,
    css:cssReducer
    
  }
})