import React from "react";
import Link from 'next/link';
import Header from './Header.js' ;
import {Button} from '@shopify/polaris';
import { Heading, Page } from "@shopify/polaris"; 
import TableData from './Tabledata.js';
import {Navigation} from '@shopify/polaris';
import {HomeMajor, OrdersMajor, ProductsMajor} from '@shopify/polaris-icons';


function Dashboard() {
    return (
        <>
            <Header />
            <Page>
                <TableData />
            </Page>    
               
        </>
    );
};
export default Dashboard;
