import { createSlice } from '@reduxjs/toolkit'

const initialState = [
    
]

const formSlice = createSlice({
    name: 'form',
    initialState,
    reducers: {
        formAdd(state, action) {
          state.push(action.payload)
        }
        // prepare(title, content, userId) {
        //   return {
        //     payload: {
        //       id: nanoid(),
        //       checked ,
        //       rating,
        //       heading,
        //       description ,
        //       name              
        //     },
        //   }
        // },
      }
  })
  console.log(formSlice);
  export const { formAdd } = formSlice.actions
  
  export default formSlice.reducer 